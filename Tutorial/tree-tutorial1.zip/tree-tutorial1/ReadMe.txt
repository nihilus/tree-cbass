Tutorial 1 - Taint-Data policy Demo
----------------------------------------------------------------
Tested on Windows 7 64-bit and Windows XP SP3

This package includes the following files:
* basicov.cpp 		- Source code for the basicov
* basicov.exe 		- Basicov program
* mytaint.txt		- Input file for basicov.exe
* ReadMe.txt 		- Read me
* TREE-TaintData.mp4	- Demo video


Summary
------------------------------------------------------------------
This package demostrates the TREE IDA Pro plugin using Taint-Data policy.
Part 1 of the demo uses non-interactive mode to generate the execution trace.
Part 2 of the demo uses interactive mode to generate the execution trace.

The basicov program is a very simple program with a buffer-overflow vulnerability.
The program reads from the file 'mytaint.txt'. The buffer-overflow occurs if 
the first character in the file is the 'b' character and the total input size 
is greater than 8 characters.

Non-interactive mode triggers on API calls and filters.
For files, the tracer will track file usages by monitoring CreateFile,ReadFile,CloseHandle (Windows).
A trace is generated when the filter matches the file opened.
For example, if the filter was set to the file 'mytaint.txt' and the program opens 'mytaint.txt' while
in trace mode, then the tracer will generate the trace.  If the program opens any other file other than
'mytaint.txt', no trace will be generated.

Interactive mode triggers when execution hits the starting point (shift-a) and ends when the execution
hits the stopping point (shift-z).
Current limitation limits input tracking to the Readfile function.  If the starting point is on Readfile,
the tracer will log the input source and the analyzer will display the source and sink properly.
If the starting point is not on Readfile, an execution trace will still be generated but the input will not 
be logged, therefore the analzyer will not be able to display the results properly.
We are working to remove this limitation.

For more information, please watch the video.

Enjoy!

*******************************************************************
Known issues
*******************************************************************
* Missing msvcr100.dll error
  On some system you will get this error because you are missing the Visual C++ 2010 runtime.
  A quick solution is to copy a known good msvcr100.dll from another system to your C:\windows\system32 directory

* R6034 error
   About the error R6034, it's caused by a bug (or misfeature) in the 
   uuid module which is used by networkx. There are two solutions here:

   1) make sure you don't have any stray msvcr90.dll in the PATH. Use 
	where msvcr90.dll" in command prompt to find offenders.

   or

   2) patch C:\Python27\Lib\uuid.py

==========================================
try:
     import ctypes, ctypes.util

     if os.name not in ['nt', 'ce']:   <- add this if
         # The uuid_generate_* routines are provided by libuuid
         # Linux and FreeBSD, and provided by libc on Mac OS X.
         for libname in ['uuid', 'c']:
==========================================

   The bug entry at python.org: http://bugs.python.org/issue17213





