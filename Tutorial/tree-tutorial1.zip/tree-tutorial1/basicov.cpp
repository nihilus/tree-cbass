// filebufov.cpp : Defines the entry point for the console application.
//

#include "windows.h"
#include <stdio.h>

HANDLE hFile = NULL;

void StackOVflow(char * sBig,int num);

int main(int argc, char* argv[])
{
	char sBigBuf[16]={0};

	hFile = CreateFile("mytaint.txt",      // Open One.txt
					  GENERIC_READ,           // Open for reading
					  0,                      // Do not share
					  NULL,                   // No security
					  OPEN_EXISTING,          // Existing file only
					  FILE_ATTRIBUTE_NORMAL,  // Normal file
					  NULL);                  // No template file

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return 1;
	}

	DWORD dwBytesRead;
	ReadFile(hFile, sBigBuf, 16, &dwBytesRead, NULL);
	
	CloseHandle(hFile);

	if(sBigBuf[0]=='b')
		StackOVflow(sBigBuf,dwBytesRead);
	else
		printf("Good!\n");

	return 0;
}

void StackOVflow(char *sBig,int num)
{
	char sBuf[8]= {0};

	for(int i=0;i<num;i++)
	{
		sBuf[i] = sBig[i];
	}
	return;
}


void Hack()
{
	MessageBox(NULL,"CBASS(Cross-platform Binary Automated Symbolic-execution System) \n               Hacking Demo ","*** You Have Been Owned!!! ***",0x00001010);
	exit(-1);
}